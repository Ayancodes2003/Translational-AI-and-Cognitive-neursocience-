"""
Models Module

This module contains model architectures.
"""
